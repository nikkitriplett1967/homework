### File

* *None*

### Instructions

* For the next 10 minutes, take a website that you yourself worked on (ex: In-Class activities, homework assignments, etc.), and utilize the Google Developer Tools to help you test changes in real-time.

* **NOTE:** Focus on getting more comfortable using the Developer Tools. Trust us. You will WANT to use these Developer Tools as you proceed in this course. 
