# :Pseudo-classes

In this activity you'll use pseudo-classes to style elements based on their state.

## Instructions

* Create a series of links and modify the pseudo-classes associated with their Default, Active, Hover, and Focus States.

* Hint: Nope. No starter code. Gotta do this from scratch :-) 

## Bonus

* If you finish early, incorporate a pseudo-class we haven’t covered in your page. Then read about “pseudo-elements” and try to incorporate one as well.

* Slack out the code and screenshot if you end up completing the bonus. 
* **Extra** - Learn about css transitions to add a fading hover effect to a link (\\&lt;a>)
