## File

* [`random-numbers-unsolved`](Unsolved/random-numbers-unsolved.html)

### Instructions

* Research how to improve on `Math.random()` to generate a random whole number between 1 and 10 instead of a random decimal number.
