### File

* _None_

### Instructions

* From scratch, create a small application that will do two things:

  1. Check which OS the user is on and alert a message that says, _"Welcome, Windows user!"_ or, _"Welcome, Mac user!"_

  2. Then check their **geolocation** and redirect them to a new page depending on if they are located in the eastern or western half of the USA.

* You'll need to do some research on how to gather some of this information, but here's a hint: it's going to be part of the `window` object we just looked at.
