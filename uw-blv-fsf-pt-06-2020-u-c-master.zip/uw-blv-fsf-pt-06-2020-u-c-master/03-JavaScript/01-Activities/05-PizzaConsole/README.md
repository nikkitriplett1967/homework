### File

* [`pizza-variables-2`](Unsolved/pizza-variables-2.html)

### Instructions

* Using the file above as a guide, modify the code so that it uses `console.log` instead of alerts to display messages.

* With a partner, discuss the difference between using `console.log` and `alert`.
