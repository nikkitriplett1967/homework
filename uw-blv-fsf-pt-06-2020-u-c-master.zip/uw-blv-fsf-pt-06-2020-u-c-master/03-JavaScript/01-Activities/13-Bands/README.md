### File

* *None*

### Instructions

* Create a website that accomplishes the following:

  * Create an array of your favorite bands.

  * With a prompt, ask the user's favorite band.

  * If it's one of your favorites, alert: "YEAH I LOVE THEM!"

  * If it's not, alert: "Nah. They're pretty lame."

  * **HINT:**  You will need to research how to use `.indexOf()`.

  * **HINT:** You will need to research how to use `.toLowerCase()`.
