# CSS Positioning

* Work with the same or different partners on this activity, but make sure **each** member of the group is typing out their own code! 

* Create a file called `positioning.html` and a file called `positioning.css`. 

* Using HTML/CSS, create the layout shown on the screen.

* For reference, the colors used on the screen are `#eee` and `#999`.

* For further reference, you can generate paragraphs of lorem ipsum text using <http://www.lipsum.com/feed/html>. You need to make this page scroll to see how the fixed position element behaves.

* HINT: Use the code from the last few activities to help get you started.
